/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author gauri
 */
public class Profile {
    private String Name;
    private String Geodata;
    private String EmailID;
    private String HPBenfNo;
    private String LicenseNo;
    private String VehIdenNo;
    private String DOB;
    private String LinkedIn;
    private String DevID;
    private String IPAdd;
    private String SSN;
    private String Img;
    private String UID;
    private String TelNo;
    private String FaxNo;
    private String MedrecNo;
    private String BankACNo;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getGeodata() {
        return Geodata;
    }

    public void setGeodata(String Geodata) {
        this.Geodata = Geodata;
    }

    public String getEmailID() {
        return EmailID;
    }

    public void setEmailID(String EmailID) {
        this.EmailID = EmailID;
    }

    public String getHPBenfNo() {
        return HPBenfNo;
    }

    public void setHPBenfNo(String HPBenfNo) {
        this.HPBenfNo = HPBenfNo;
    }

    public String getLicenseNo() {
        return LicenseNo;
    }

    public void setLicenseNo(String LicenseNo) {
        this.LicenseNo = LicenseNo;
    }

    public String getVehIdenNo() {
        return VehIdenNo;
    }

    public void setVehIdenNo(String VehIdenNo) {
        this.VehIdenNo = VehIdenNo;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getLinkedIn() {
        return LinkedIn;
    }

    public void setLinkedIn(String LinkedIn) {
        this.LinkedIn = LinkedIn;
    }

    public String getDevID() {
        return DevID;
    }

    public void setDevID(String DevID) {
        this.DevID = DevID;
    }

    public String getIPAdd() {
        return IPAdd;
    }

    public void setIPAdd(String IPAdd) {
        this.IPAdd = IPAdd;
    }

    public String getImg() {
        return Img;
    }

    public void setImg(String Img) {
        this.Img = Img;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getTelNo() {
        return TelNo;
    }

    public void setTelNo(String TelNo) {
        this.TelNo = TelNo;
    }

    public String getFaxNo() {
        return FaxNo;
    }

    public void setFaxNo(String FaxNo) {
        this.FaxNo = FaxNo;
    }

    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    public String getMedrecNo() {
        return MedrecNo;
    }

    public void setMedrecNo(String MedrecNo) {
        this.MedrecNo = MedrecNo;
    }

    public String getBankACNo() {
        return BankACNo;
    }

    public void setBankACNo(String BankACNo) {
        this.BankACNo = BankACNo;
    }
    
    
    
    
    
    
    
    
}
