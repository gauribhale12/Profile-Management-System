/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author gauri
 */
public class MenuDirectory {
    private ArrayList<Menu> MenuList;
    
    public MenuDirectory(){
    this.MenuList =new ArrayList<Menu>();
}    
public Menu addMenu(){
      Menu newMenu = new Menu();
      MenuList.add(newMenu);
      return newMenu;    
}
}
