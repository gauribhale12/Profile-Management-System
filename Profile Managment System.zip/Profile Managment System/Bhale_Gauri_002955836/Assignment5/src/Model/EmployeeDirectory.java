/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author gauri
 */
public class EmployeeDirectory {
    private ArrayList<Employee> EmployeeList;
    
    public EmployeeDirectory(){
    this.EmployeeList =new ArrayList<Employee>();
}

    public ArrayList<Employee> getEmployeeList() {
        return EmployeeList;
    }

    public void setEmployeeList(ArrayList<Employee> EmployeeList) {
        this.EmployeeList = EmployeeList;
    }
    public Employee addemp(){
        Employee newemp = new Employee();
      EmployeeList.add(newemp);
      return newemp;
    }
    public void removeemp(int index){
       EmployeeList.remove(index);
    }

}