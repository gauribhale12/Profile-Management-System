/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author gauri
 */

public class Menu {
    private String Dish;
    private String Price;

    public String getDish() {
        return Dish;
    }

    public void setDish(String Dish) {
        this.Dish = Dish;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }
}
